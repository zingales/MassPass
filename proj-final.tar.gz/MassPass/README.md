MassPass
========

To setup:
1) download git repo
2) got to chrome extensions
3) enable developer mode
4) load unpack extension and point it to MassPass/chrome_extension. 

