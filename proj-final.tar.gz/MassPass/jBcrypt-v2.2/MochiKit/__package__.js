dojo.kwCompoundRequire({
    "common": [
        "MochiKit.Base",
        "MochiKit.Iter",
        "MochiKit.Logging",
        "MochiKit.DateTime",
        "MochiKit.Format",
        "MochiKit.Async",
        "MochiKit.DOM",
        "MochiKit.Style",
        "MochiKit.LoggingPane",
        "MochiKit.Color",
        "MochiKit.Signal",
        "MochiKit.Position",
        "MochiKit.Visual"
    ]
});
dojo.provide("MochiKit.*");
